# Toonator

Online animation creation and sharing platform, migrated from Vercel to Replit.

## Architecture

- **Static frontend**: HTML/CSS/JS served directly from the root directory
- **Backend**: Express.js server (`server.js`) handles routing and serves the Vercel-style API handlers
- **Database**: Supabase (hosted externally) — accessed via the public anon key from both client and server
- **API handlers**: `api/toon/[id].js` and `api/user/[username].js` — originally Vercel serverless functions, now loaded as ES modules by Express

## How it runs

The Express server (`server.js`) replaces Vercel's routing layer:
- `/toon/:id` → `api/toon/[id].js` handler (server-rendered toon page)
- `/user/:username` and `/user/:username/:page` → `api/user/[username].js` handler (server-rendered profile page)
- All other paths → static files from the root directory

## Running

```
node server.js
```

Listens on port 5000, bound to `0.0.0.0` for Replit compatibility.

## Dependencies

- `express` — web server and routing

## Key Files

- `server.js` — main Express server (created for Replit migration)
- `package.json` — Node.js project config (type: module for ESM)
- `index.html` — main homepage
- `api/toon/[id].js` — server-side toon page renderer
- `api/user/[username].js` — server-side user profile renderer
- `js/config.js` — Supabase client config (client-side)
- `vercel.json` — original Vercel routing config (kept for reference)
