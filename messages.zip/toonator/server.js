import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import toonHandler from './api/toon/[id].js';
import userHandler from './api/user/[username].js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = 5000;

app.use(express.json());

app.get('/toon/:id', (req, res) => {
  const adaptedReq = {
    query: { id: req.params.id },
    method: req.method,
    headers: req.headers
  };
  toonHandler(adaptedReq, res);
});

app.get('/user/:username', (req, res) => {
  const adaptedReq = {
    query: { username: req.params.username, page: req.query.page },
    method: req.method,
    headers: req.headers
  };
  userHandler(adaptedReq, res);
});

app.get('/user/:username/:page', (req, res) => {
  const adaptedReq = {
    query: { username: req.params.username, page: req.params.page },
    method: req.method,
    headers: req.headers
  };
  userHandler(adaptedReq, res);
});

app.use(express.static(__dirname, {
  index: 'index.html',
  extensions: ['html']
}));

app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});
